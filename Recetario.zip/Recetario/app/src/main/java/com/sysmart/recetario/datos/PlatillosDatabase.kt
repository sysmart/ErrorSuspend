package com.sysmart.recetario.datos

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [ClsEvento::class],
    version = 1,
    exportSchema = false
)
abstract class PlatillosDatabase : RoomDatabase() {

    abstract fun eventoDao(): EventoDao

    companion object {
        @Volatile
        private var INSTANCE: PlatillosDatabase? = null

        fun getDatabase(context: Context): PlatillosDatabase {
            // if INSTANCE es null, crea la base de datos, si no regresa el valor de INSTANCE
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    PlatillosDatabase::class.java,
                    "platillos_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
package com.sysmart.recetario.datos

import androidx.lifecycle.LiveData
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity
data class ClsEvento(
    @PrimaryKey(autoGenerate = true) val idEvento: Int = 0,
    val Nombre: String,
    val Personas: Int,
    val Total: Double
)

@Dao
interface EventoDao {
    // Selecciona solo los Ingrediente nuevos o modificados para la interface
    @Query(
        "Select 0 as idEvento, '<<Nuevo>>' as Nombre, 0 as Personas, 0 as Total" +
                " Union Select idEvento, Nombre, Personas, Total From ClsEvento"
    )
    fun selEvento(): Flow<List<ClsEvento>>

    @Query("Select * From ClsEvento")
    fun selEventos(): Flow<List<ClsEvento>>

    @Query("Select * From ClsEvento WHERE idEvento = :idEvento")
    fun selEventoXId(idEvento: Int): Flow<ClsEvento>

    @Query("Select COALESCE(COUNT(*), 0) From ClsEvento")
    fun cuentaEventos(): LiveData<Int>

    @Query("Select COALESCE (MAX(idEvento), 0) + 1 From ClsEvento;")
    fun selIdEvento(): LiveData<Int>

    // Especifica la estrategia de conflicto como REPLACE
    // Cuando el usuario intenta agregar a la base de datos un Cliente que ya existe Room ignora el conflicto.

    @Insert(onConflict = OnConflictStrategy.REPLACE)
     fun insert(clsEvento: ClsEvento)

    @Delete
    suspend fun delete(clsEvento: ClsEvento)

    @Update
    suspend fun update(clsEvento: ClsEvento)

    @Transaction
    suspend fun initEvento() {
        deleteEvento()
    }

    @Query("DELETE FROM ClsEvento")
    suspend fun deleteEvento(): Int
}